﻿namespace MyRadio
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.One_trackbar = new System.Windows.Forms.TrackBar();
            this.Two_trackbar = new System.Windows.Forms.TrackBar();
            this.Three_trackbar = new System.Windows.Forms.TrackBar();
            this.Four_trackbar = new System.Windows.Forms.TrackBar();
            this.Five_trackbar = new System.Windows.Forms.TrackBar();
            this.Six_trackbar = new System.Windows.Forms.TrackBar();
            this.Seven_trackbar = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.One_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Two_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Three_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Four_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Five_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Six_trackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Seven_trackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // One_trackbar
            // 
            this.One_trackbar.Location = new System.Drawing.Point(12, 13);
            this.One_trackbar.Name = "One_trackbar";
            this.One_trackbar.Size = new System.Drawing.Size(270, 45);
            this.One_trackbar.TabIndex = 19;
            this.One_trackbar.Value = 10;
            this.One_trackbar.Scroll += new System.EventHandler(this.One_trackbar_Scroll);
            // 
            // Two_trackbar
            // 
            this.Two_trackbar.Location = new System.Drawing.Point(12, 63);
            this.Two_trackbar.Name = "Two_trackbar";
            this.Two_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Two_trackbar.TabIndex = 20;
            this.Two_trackbar.Value = 10;
            this.Two_trackbar.Scroll += new System.EventHandler(this.Two_trackbar_Scroll);
            // 
            // Three_trackbar
            // 
            this.Three_trackbar.Location = new System.Drawing.Point(12, 114);
            this.Three_trackbar.Name = "Three_trackbar";
            this.Three_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Three_trackbar.TabIndex = 21;
            this.Three_trackbar.Value = 10;
            this.Three_trackbar.Scroll += new System.EventHandler(this.Three_trackbar_Scroll);
            // 
            // Four_trackbar
            // 
            this.Four_trackbar.Location = new System.Drawing.Point(12, 165);
            this.Four_trackbar.Name = "Four_trackbar";
            this.Four_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Four_trackbar.TabIndex = 22;
            this.Four_trackbar.Value = 10;
            this.Four_trackbar.Scroll += new System.EventHandler(this.Four_trackbar_Scroll);
            // 
            // Five_trackbar
            // 
            this.Five_trackbar.Location = new System.Drawing.Point(12, 216);
            this.Five_trackbar.Name = "Five_trackbar";
            this.Five_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Five_trackbar.TabIndex = 23;
            this.Five_trackbar.Value = 10;
            this.Five_trackbar.Scroll += new System.EventHandler(this.Five_trackbar_Scroll);
            // 
            // Six_trackbar
            // 
            this.Six_trackbar.Location = new System.Drawing.Point(12, 267);
            this.Six_trackbar.Name = "Six_trackbar";
            this.Six_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Six_trackbar.TabIndex = 24;
            this.Six_trackbar.Value = 10;
            this.Six_trackbar.Scroll += new System.EventHandler(this.Six_trackbar_Scroll);
            // 
            // Seven_trackbar
            // 
            this.Seven_trackbar.Location = new System.Drawing.Point(12, 318);
            this.Seven_trackbar.Name = "Seven_trackbar";
            this.Seven_trackbar.Size = new System.Drawing.Size(270, 45);
            this.Seven_trackbar.TabIndex = 25;
            this.Seven_trackbar.Value = 10;
            this.Seven_trackbar.Scroll += new System.EventHandler(this.Seven_trackbar_Scroll);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(301, 366);
            this.Controls.Add(this.Seven_trackbar);
            this.Controls.Add(this.Six_trackbar);
            this.Controls.Add(this.Five_trackbar);
            this.Controls.Add(this.Four_trackbar);
            this.Controls.Add(this.Three_trackbar);
            this.Controls.Add(this.Two_trackbar);
            this.Controls.Add(this.One_trackbar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "AudioWizard>>Mixer";
            ((System.ComponentModel.ISupportInitialize)(this.One_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Two_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Three_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Four_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Five_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Six_trackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Seven_trackbar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar One_trackbar;
        private System.Windows.Forms.TrackBar Two_trackbar;
        private System.Windows.Forms.TrackBar Three_trackbar;
        private System.Windows.Forms.TrackBar Four_trackbar;
        private System.Windows.Forms.TrackBar Five_trackbar;
        private System.Windows.Forms.TrackBar Six_trackbar;
        private System.Windows.Forms.TrackBar Seven_trackbar;
    }
}